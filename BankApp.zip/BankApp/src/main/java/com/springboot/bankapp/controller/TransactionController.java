package com.springboot.bankapp.controller;

import java.security.Principal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.bankapp.dto.Deposit;
import com.springboot.bankapp.dto.Transfer;
import com.springboot.bankapp.model.Customer;
import com.springboot.bankapp.model.Transaction;
import com.springboot.bankapp.service.CustomerService;
import com.springboot.bankapp.service.TransactionService;

@RestController
public class TransactionController {
	
	@Autowired
	private TransactionService transactionService;
	
	@Autowired
	private CustomerService customerService;
	
	@PostMapping("/transfer")
	public Transaction doTransfer(Principal principal ,@RequestBody Transfer transfer ) {
		/**
		 * get the username and then transfer the accoount number 
		 * and amount in request body 
		 */
		String username=principal.getName();
		
//		/** STEP 1:* Fetch details of fromAccount*
//		 *  1.1 fetch fromAccountNumber from username** 
//		 *  STEP 2:* 
//		 *  2.1 DEBIT the amount from fromAccountNumber / update the balance* 
//		 *  2.2 CREDIT the amount to toAccountNumber / update the balance**
//		 *  STEP 3:*
//		 *   3.1 insert the entry of transfer in transaction table
//		* fetch the data accroding to dates 
//		*/
	
		//1
		String fromAccountNumber=transactionService.fetchFromAccountNumber(username);
		
		//2.1
		transactionService.updateBalance(fromAccountNumber,transfer.getAmount());

		transactionService.creditBalance(transfer.getToAccountNumber(),transfer.getAmount());
		
		Transaction transaction = new Transaction();
		transaction.setAccountFrom(fromAccountNumber);
		transaction.setAccountTo(transfer.getToAccountNumber());
		transaction.setBalance(transfer.getAmount());
         transaction.setOperationType("TRANSFER");
         transaction.setDateOfTransaction(new Date());
         
		return transactionService.saveTransaction(transaction);
		
	}
	
	@GetMapping("/statement/{startDate}/{endDate}")
	public List<Transaction> generateStatement(Principal principal, 
			@PathVariable("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate startDate, 
			@PathVariable("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate endDate) {
		 
		String username=principal.getName(); 
		
		/* 
		 * Step 1: extract account number based on username
		 */
		
		/*
		 * Step 2:  
		 * Fetch transactions for above account number
		 * this number should be either in  account_from or account_to
		 * this will give me List<Tansaction>
		 */
		
		/*
		 * Step 3: 
		 * From List<Transaction> of step-2, I will filter this based on 
		 * startDate and endDate given. 
		 * return this List<Transaction>
		 */
		
		//Step 1
		String accountNumber = transactionService.fetchFromAccountNumber(username);
		
		//Step 2
		List<Transaction> list = transactionService.fetchTransactionsByAccountNumber(accountNumber);
		
		//Step 3
		try {
			//convert LocalDate to Date
			Date startDateToDate = new SimpleDateFormat("yyyy-MM-dd").parse(startDate.toString());
			Date endDateToDate = new SimpleDateFormat("yyyy-MM-dd").parse(endDate.toString());
			//2022-01-10
			list = list.parallelStream()
					.filter(t-> t.getDateOfTransaction().compareTo(startDateToDate) >= 0)
					.filter(t-> t.getDateOfTransaction().compareTo(endDateToDate) <= 0)
					.collect(Collectors.toList());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return list; 
	}
	
	@PostMapping("/deposit")
	public Transaction doDeposit(Principal principal ,@RequestBody Deposit deposit ) {
		/**
		 * get the username and then transfer the accoount number 
		 * and amount in request body 
		 */
		
		/**
		 * Steps :
		 * Step 1: fetch the account number based on username
		 * 
		 * Step 2 : update the balance and  add amount  to the balance
		 * 
		 * 
		 * Step 3: 
		 * add an entry in transaction Table 
		 * operation Type = DEPOSIT
		 * 
		*  accountfrom = account to = accountNumber (from step 1)
		 */
		
		//1.
		
		String username=principal.getName();
		
		String accountNumber = transactionService.fetchFromAccountNumber(username);
		
		//2
		transactionService.depositBalance(accountNumber,deposit.getAmount());
		
		//3
		Transaction transaction = new Transaction();
		transaction.setAccountFrom(accountNumber);
		transaction.setAccountTo(accountNumber);
		transaction.setBalance(deposit.getAmount());
         transaction.setOperationType("DEPOSIT");
         transaction.setDateOfTransaction(new Date());
         
		return transactionService.saveTransaction(transaction);
		
		
	}
	
	@GetMapping("/balance")
	public double showBalance(Principal principal) {
		
		/*
		 * fetch user name
		 * and then extract account number
		 * and then extract balance
		 * 
		 */
		String username=principal.getName();
		
		//Step 1
	 String accountNumber = transactionService.fetchFromAccountNumber(username);
	
	 
	 return  transactionService.fetchBalance(accountNumber);

		}
	
	@PutMapping("/edit")
	public void getCustomer(Principal principal,@RequestBody Customer customer) {
		
		/*
		 * before this api call get oneEdit
		 * 
		 * 
		 * Step 1 : 
		 * fetch username from principal
		 * fetch customer ID based on username as step 1.
		 * and write edit for city and address. not need to use IN 
		 * 
		 * step 2 : 
		 * updated customer table with new address and city
		 * refer updated query from userRepository
		 * 
		 * return updated customer object
		 * 
		 */
		
		String username=principal.getName();
	   
	    Long customerID  =transactionService.fetchcustomerID(username);
	    System.out.println(username);
//	     customer = new Customer();
//	     customer.setAddress(customer.getAddress());
//	     customer.setCity(customer.getCity());
//
//	     
//	    return  customerService.saveCustomer(customer);
	//return transactionService.updateDetails(customerID,customer.getAddress(),customer.getCity());
		
	}
	
	
	}

	
