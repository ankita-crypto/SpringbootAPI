package com.springboot.telusko.controller;

public class EmployeeController {

}
