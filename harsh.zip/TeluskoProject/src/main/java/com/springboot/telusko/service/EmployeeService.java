package com.springboot.telusko.service;

public class EmployeeService {

}
