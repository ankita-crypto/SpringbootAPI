package com.springboot.library.entity;

import com.springboot.library.utils.RoomTypes;

public class Rooms {
	private long roomId;
	private int numberRoomsOfThisType;
	private RoomTypes roomType;
	public long getRoomId() {
		return roomId;
	}
	public void setRoomId(long roomId) {
		this.roomId = roomId;
	}
	public int getNumberRoomsOfThisType() {
		return numberRoomsOfThisType;
	}
	public void setNumberRoomsOfThisType(int numberRoomsOfThisType) {
		this.numberRoomsOfThisType = numberRoomsOfThisType;
	}
	public RoomTypes getRoomType() {
		return roomType;
	}
	public void setRoomType(RoomTypes roomType) {
		this.roomType = roomType;
	}
	@Override
	public String toString() {
		return "Rooms [roomId=" + roomId + ", numberRoomsOfThisType=" + numberRoomsOfThisType + ", roomType=" + roomType
				+ "]";
	}
	
	

}
