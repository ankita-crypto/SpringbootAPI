package com.springboot.library.utils;

public enum RoomTypes {
	AC_SINGLE,
	AC_TWO_SHARING,
	AC_FOUR_SHARING,
	FIVE_SHARING,
	FOUR_SHARING,
	THREE_SHARING,
	TWO_SHARING,
	SINGLE_ROOMS;

}
