package com.springboot.microservices.api.hyterix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HyterixDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
