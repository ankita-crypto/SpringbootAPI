package com.springboot.bankapp.repository;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.ResponseEntity;

import com.springboot.bankapp.model.Account;
import com.springboot.bankapp.model.Customer;
import com.springboot.bankapp.model.Help;
import com.springboot.bankapp.model.UserInfo;

public interface UserRepository extends JpaRepository<UserInfo, Long>{

	public UserInfo findByUsername(String username);

	@Query("select a.accountNumber from Customer c join c.userInfo u join c.account a where u.username=?1")
	public String fetchFromAccountNumber(String username);

	@Transactional
	@Modifying
	@Query("update Account a SET a.balance=a.balance-?2 where a.accountNumber=?1")
	public void updateBalance(String fromAccountNumber, double amount);

	@Transactional
	@Modifying
	@Query("update Account a SET a.balance=a.balance+?2 where a.accountNumber=?1")
	public void creditBalance(String toAccountNumber, double amount);

	
	@Transactional
	@Modifying
	@Query("update Account a SET a.balance=a.balance+?2 where a.accountNumber=?1")
	public void depositBalance(String accountNumber, double amount);

	@Query("select a.balance  from Account a where a.accountNumber = ?1")
	public Double fetchBalance(String accountNumber);

	@Query("select h  from Help h")
	public Help doHelp(Help help);
	
	
    

	
	@Query("select c from Customer c join c.userInfo u join c.account a where u.username=?1")
	public Long fetchcustomerID(String username);
	
//	
//    @Query("update Customer c SET c.city=?3 where c.id=?")
	//public Customer updateBalance(Long customerID, String address, String city);
	
//	this is a simple edit query. 
	//fetch customer ID based on username as step 1. 
	//and write edit for city and address. not need to use IN

	

	
	
	
	




}
