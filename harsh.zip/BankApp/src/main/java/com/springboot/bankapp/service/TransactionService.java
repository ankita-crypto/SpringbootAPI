package com.springboot.bankapp.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.bankapp.model.Account;
import com.springboot.bankapp.model.Customer;
import com.springboot.bankapp.model.Help;
import com.springboot.bankapp.model.Transaction;
import com.springboot.bankapp.repository.TransactionRepository;
import com.springboot.bankapp.repository.UserRepository;

@Service
public class TransactionService {

	@Autowired
	private UserRepository  userRepository;
	
	@Autowired
	private TransactionRepository transactionRepository ;
	
	
	public String fetchFromAccountNumber(String username) {
		
		return userRepository.fetchFromAccountNumber(username);
		
	}
	public void updateBalance(String fromAccountNumber, double amount) {
		userRepository.updateBalance(fromAccountNumber,amount);
		
	}
	public void creditBalance(String toAccountNumber, double amount) {
		userRepository.creditBalance(toAccountNumber,amount);
		
	}
	
	//save the transcationns
	public Transaction saveTransaction(Transaction transaction) {
		
		return transactionRepository.save(transaction);
	}
	
	public List<Transaction> fetchTransactionsByAccountNumber(String accountNumber) {
		
		return transactionRepository.fetchTransactionsByAccountNumber(accountNumber);
	}
	public void depositBalance(String accountNumber, double amount) {
		userRepository.depositBalance(accountNumber,amount);
		
	}
	public double fetchBalance(String accountNumber) {
		
		return userRepository.fetchBalance(accountNumber);
	}
	
//	public void updateDetails(String username, String address, String city) {
//		userRepository.updateDetails(username,address,city);
//		
//	}
	
	public Long fetchcustomerID(String username) {
		
		return userRepository.fetchcustomerID(username);
	}
//	public Customer updateDetails(Long customerID, String address, String city) {
//		
//	return	userRepository.updateBalance(customerID,address,city);
//		
//	}
//	
	
	
}
