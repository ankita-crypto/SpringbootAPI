package com.springboot.bankapp.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.bankapp.model.Customer;
import com.springboot.bankapp.model.Help;
import com.springboot.bankapp.model.UserInfo;
import com.springboot.bankapp.repository.CustomerRepository;
import com.springboot.bankapp.repository.HelpRepository;
import com.springboot.bankapp.service.CustomerService;
import com.springboot.bankapp.service.TransactionService;

@RestController
public class CustomerController {

	
	@Autowired
	private CustomerService customerService;
	
	
	@Autowired
	private TransactionService transactionService;
	
	@Autowired
	private HelpRepository helpRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@PostMapping("/customer")
	public Customer postCustomer(@RequestBody Customer customer) {
		
		return customerService.postCustomer(customer);
	}
	
	@DeleteMapping("/customer/{id}")
	public void deleteCustomer(@PathVariable("id") Long id) {
		customerService.deleteCustomer(id);
	}
	
	@GetMapping("/user")
	public UserInfo getUser(Principal principal) {
		UserInfo user = customerService.getUserByName(principal.getName());
		return user;
	}
	
	@PostMapping("/help")
	public Help postHelp(@RequestBody Help help) {
		
		return helpRepository.save(help);
	}
	
	@GetMapping("/help")
	public List<Help> getAllFAQ() {
		return customerService.getAllFAQ(); 
				
	}
	
	
	}
	
	

