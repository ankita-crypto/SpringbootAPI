package com.example.harsh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/*
 * Application start point
 */
@SpringBootApplication
public class HarshApplication {

	public static void main(String[] args) {
		SpringApplication.run(HarshApplication.class, args);
	}

}
