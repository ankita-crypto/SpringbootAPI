package com.springboot.library.dao;

import java.util.List;

import com.springboot.library.entity.Host;


public interface HostDao extends CrudRepository<Host, Integer> {
	List<Host> findAll();
}