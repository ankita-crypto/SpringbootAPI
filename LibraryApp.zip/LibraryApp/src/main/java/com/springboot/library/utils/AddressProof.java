package com.springboot.library.utils;

public enum AddressProof {
	
	AUDHAR_CARD,
	PAN_CARD,
	PASSPORT,
	DRIVING_LICENSE

}
