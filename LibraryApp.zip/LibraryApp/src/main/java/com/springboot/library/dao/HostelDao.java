package com.springboot.library.dao;

import java.util.List;

import com.springboot.library.entity.Hostel;

public interface HostelDao extends CrudRepository<Hostel, Long>{
    List<Hostel> findAll();

	Object save(Hostel addHostelToHost);

	boolean exists(long hostelId);
}
