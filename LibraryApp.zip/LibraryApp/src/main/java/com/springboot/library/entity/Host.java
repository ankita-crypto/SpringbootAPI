package com.springboot.library.entity;

import java.util.List;

import com.springboot.library.utils.AddressProof;


public class Host {
	
	 private long hostId;

	   
	    private String hostName;
	    private String hostEmail;
	    private String hostPassword;
	    private String hostPicPath;
	    private AddressProof addressProof;
	    private String addressProofId;
	    private List<Hostel> hostels;
		public long getHostId() {
			return hostId;
		}
		public void setHostId(long hostId) {
			this.hostId = hostId;
		}
		public String getHostName() {
			return hostName;
		}
		public void setHostName(String hostName) {
			this.hostName = hostName;
		}
		public String getHostEmail() {
			return hostEmail;
		}
		public void setHostEmail(String hostEmail) {
			this.hostEmail = hostEmail;
		}
		public String getHostPassword() {
			return hostPassword;
		}
		public void setHostPassword(String hostPassword) {
			this.hostPassword = hostPassword;
		}
		public String getHostPicPath() {
			return hostPicPath;
		}
		public void setHostPicPath(String hostPicPath) {
			this.hostPicPath = hostPicPath;
		}
		public AddressProof getAddressProof() {
			return addressProof;
		}
		public void setAddressProof(AddressProof addressProof) {
			this.addressProof = addressProof;
		}
		public String getAddressProofId() {
			return addressProofId;
		}
		public void setAddressProofId(String addressProofId) {
			this.addressProofId = addressProofId;
		}
		public List<Hostel> getHostels() {
			return hostels;
		}
		public void setHostels(List<Hostel> hostels) {
			this.hostels = hostels;
		}
		
		@Override
		public String toString() {
			return "Host [hostId=" + hostId + ", hostName=" + hostName + ", hostEmail=" + hostEmail + ", hostPassword="
					+ hostPassword + ", hostPicPath=" + hostPicPath + ", addressProofId=" + addressProofId
					+ ", hostels=" + hostels + "]";
		}
	    
	    
	    
	    

}
