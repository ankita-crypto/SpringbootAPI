package com.example.harsh.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.harsh.model.Customer;
import com.example.harsh.repository.CustomerRepository;

@RestController
public class CustomerController {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	/*get
	 * Post - put and delete api using jpa
	 */
	
	@PostMapping("/customer")
	public Customer insertCustomer(@RequestBody Customer customer) {
		return customerRepository.save(customer);
		
	}
    @GetMapping("/customer")
    public List<Customer> getCustomer()
     {
	return customerRepository.findAll();
      }
	
    @GetMapping("/customer{id}")
    public Customer getOneCustomer(@PathVariable("id") long id) {
	return customerRepository.getById(id);
      }


    @PutMapping("/customer{id}")
     public Customer putCustomer(@PathVariable("id") long id,@RequestBody Customer newCustomer)
      {
	//fetch the customer based on existing id
	
	Customer customerDB = customerRepository.getById(id);
	//set the new value
	
	customerDB.setName(newCustomer.getName());
	customerDB.setCity(newCustomer.getCity());
	
	//save the name
	return customerRepository.save(customerDB);
}
    @DeleteMapping("/customer")
    
    public void deleteCustomer(@RequestParam("id") long id)
    {
    	customerRepository.deleteById(id);
    }
}
