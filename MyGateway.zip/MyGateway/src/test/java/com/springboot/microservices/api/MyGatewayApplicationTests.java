package com.springboot.microservices.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
