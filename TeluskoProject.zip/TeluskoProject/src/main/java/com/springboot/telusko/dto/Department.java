package com.springboot.telusko.dto;

public class Department {

}
