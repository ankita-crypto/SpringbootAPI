package com.springboot.telusko.repository;

public class EmployeeJPAClass {

}
