package com.springboot.telusko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeluskoProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeluskoProjectApplication.class, args);
	}

}
