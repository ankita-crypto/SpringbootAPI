package com.springboot.telusko;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeluskoProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
