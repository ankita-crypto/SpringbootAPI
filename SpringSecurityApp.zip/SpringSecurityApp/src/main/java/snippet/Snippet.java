package snippet;

public class Snippet {
	@Override
		protected void configure(AuthenticationManagerBuilder auth) throws Exception {
			auth.authenticationProvider(getDBAuthenticator());
		}
}

